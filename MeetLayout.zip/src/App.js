import './App.css';
import MeetLayout from './MeetLayout';

function App() {
  return (
    <div className="App">
    <MeetLayout/>
    </div>
  );
}

export default App;
